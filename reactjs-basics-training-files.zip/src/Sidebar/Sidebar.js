import React from 'react';

const Sidebar = () => {
    return(
        <div>
            <h1>Sidebar</h1>
            
            <p>Of course, there are companies out there that have great web writers internally, but most don’t. And the thought of a company turning a great website content strategy (that we slaved over) into an ineffective “brochure site” gives me heartburn. But sometimes you have to pick your battles.</p>

            <p>In cases where we give in and let the client take the content reins, we at least want to make sure they are equipped with a template that gives them a fighting chance to produce effective website content that drives action. Here is a template we like to use, and an explanation of what’s included.</p>
        </div>
    );
}

export default Sidebar;