import React from 'react';
import './App.css';
import luxury from './images/luxury.png';

class App extends React.Component {
  render() {
    let hl = {
      color: 'red', 
      backgroundColor: 'yellowgreen'
    }

    let userName = 'jay';
    let userAge = 23;
    let userStatus = true;

    let showUser = '';
    if(userStatus) {
      showUser = (
        <div>
          <p>user name : {userName}</p>
          <p>user age : {userAge}</p>
        </div>
      );
    } else {
      showUser = (
        <div>
          <p>no such user</p>
        </div>
      );
    }

    let showCount = 0;
    let i = 0;
    while(i < 5) {
      showCount = (
        <div>
          <p>the current count : {i}</p>
        </div>
      );
      i++;
    }

    let imgStyle = {
      width: '190px', 
      height: '110px'
    }

    return(
      <div>
        <h1>Sample App!</h1>
        
        <p>its a <span style={hl}>multi</span> statement</p>
        
        <p><img src={luxury} style={imgStyle} /></p>

        <p><span style={hl}>reactjs</span>: it is an open source javscript library, which used to build single page applications <span style={hl}>single page applications:</span>  loading all the required assets (html, css, images, file etc.,) in the initial stage of your appl lands into client</p>

        <p>expr., : {23 + 73}</p>
        

        <p>user status : {userStatus ? 'true' : 'false'}</p>

        <p>user concept: {showUser}</p>

        <p>showCount : {showCount}</p>
      </div>
    );
  }
}

export default App;