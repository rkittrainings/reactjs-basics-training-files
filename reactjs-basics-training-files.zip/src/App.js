import React from 'react';
import './App.css';
import Person from './Person/Person';
import Sidebar from './Sidebar/Sidebar';

class App extends React.Component {
  state = {
    persons: [
      { name: "max", age: 23 }, 
      { name: "jack", age: 26 }, 
      { name: "snu", age: 65 }, 
      { name: "scott", age: 25 }
    ], 
    showPersons: true
  }

  switchNameHandler = (newName, newAge) => {
    this.setState({
      persons: [
        { name: "ma_x", age: 123 }, 
        { name: newName, age: newAge }, 
        { name: "scot_t", age: 125 }
      ] 
    })
  }

  changeNameHandler = (event) => {
    this.setState({
      persons: [
        { name: "ma_x", age: 123 }, 
        { name: event.target.value, age: 43 }, 
        { name: "scot_t", age: 125 }
      ] 
    })
  }

  togglePersonsHandler = () => {
    const doesShow = this.state.showPersons;
    this.setState({
      showPersons: !doesShow
    })
  }

  render() { 
    let persons = null;

    if(this.state.showPersons) {
      persons = (
            <div className="row">
                {this.state.persons.map(person => {
                  return(<div className="col-sm-4"><Person name = {person.name} age = {person.age} /></div>)
                })}
            </div>
      );
    } else {
      persons = (
        <div className="row">
          <div className="col-sm-12">
            <p> no persons found! </p>
          </div>
        </div>
      );
    }
    return(
      <div className="container">
        <div className="row">
          <div className="col-sm-9">
            <h1>A Template for Killer Website Content</h1>

            <p>Over the years of developing websites for clients, I’ve learned that the age-old adage, “If you want it done right, you gotta do it yourself,” can be a two-way street.</p>

            <p>Of course, there are companies out there that have great web writers internally, but most don’t. And the thought of a company turning a great website content strategy (that we slaved over) into an ineffective “brochure site” gives me heartburn. But sometimes you have to pick your battles.</p>

            <p>In cases where we give in and let the client take the content reins, we at least want to make sure they are equipped with a template that gives them a fighting chance to produce effective website content that drives action. Here is a template we like to use, and an explanation of what’s included.</p>

            <button type = "button" className = "btn btn-primary mr-3 mb-3" onClick = {this.switchNameHandler.bind(this, 'qwer', 54)}> switch name </button>

            <button type = "button" className = "btn btn-info ml-3 mb-3" onClick = {this.togglePersonsHandler}> toggle effect </button>
            <hr />
            
            {persons}
            

          </div>
          <div className="col-sm-3">
            <Sidebar />
          </div>
        </div>
      </div>
    );
  }
}

export default App;