import React from "react";
import './Person.css';

const person = (props) => {
    return(
        <div className="container">
            <div className="row">
                <div className="col-sm-12">
                    <div className="card">
                        <div className="card-body">
                            <p onClick={props.switchname}>I am a {props.name}, and my age is {props.age}</p>
                            <p><input className="form-control" onChange={props.changename} /></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default person;